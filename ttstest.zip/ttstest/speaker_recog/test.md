pip3 install pveagledemo


eagle_demo_mic enroll --access_key ZDGNz5X2kMCfDPyPITPCm9mdJM/RkO9n7jDEUF1CVhdsUS9cuA01YQ== --output_profile_path /home/ubuntu/ttstest/speaker_recog/speaker/shh.eagle

eagle_demo_mic test --access_key ZDGNz5X2kMCfDPyPITPCm9mdJM/RkO9n7jDEUF1CVhdsUS9cuA01YQ== --input_profile_paths /home/ubuntu/ttstest/speaker_recog/speaker/shh.eagle
